package com.zybooks.projecttwoaronov;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Name and Version
    private static final String DATABASE_NAME = "EventPlanner.db";
    private static final int DATABASE_VERSION = 1;

    // Table and Column Names for the 'users' table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Table and Column Names for the 'events' table
    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "id";
    public static final String COLUMN_EVENT_NAME = "event_name";
    public static final String COLUMN_EVENT_DATE = "event_date";
    public static final String COLUMN_EVENT_TIME = "event_time";
    public static final String COLUMN_EVENT_DESCRIPTION = "event_description";

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            // Create 'users' table
            String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT UNIQUE, " +
                    COLUMN_PASSWORD + " TEXT)";
            db.execSQL(CREATE_USERS_TABLE);

            // Create 'events' table
            String CREATE_EVENTS_TABLE = "CREATE TABLE " + TABLE_EVENTS + " (" +
                    COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_EVENT_NAME + " TEXT, " +
                    COLUMN_EVENT_DATE + " TEXT, " +
                    COLUMN_EVENT_TIME + " TEXT, " +
                    COLUMN_EVENT_DESCRIPTION + " TEXT)";
            db.execSQL(CREATE_EVENTS_TABLE);

            Log.d("DatabaseHelper", "Tables created successfully");
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error creating tables", e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
            onCreate(db);
            Log.d("DatabaseHelper", "Database upgraded successfully");
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error upgrading database", e);
        }
    }

    // Hash Passwords
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            String hashedPassword = Base64.encodeToString(hash, Base64.DEFAULT).trim();
            Log.d("DatabaseHelper", "Hashed Password: " + hashedPassword); // Log the hashed password
            return hashedPassword;
        } catch (NoSuchAlgorithmException e) {
            Log.e("DatabaseHelper", "Password hashing failed", e);
            return null;
        }
    }

    // Add a new user
    public long addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String hashedPassword = hashPassword(password); // Hash the password
        if (hashedPassword == null) {
            Log.e("DatabaseHelper", "Failed to hash password during user creation");
            return -1;
        }

        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, hashedPassword);

        try {
            long result = db.insert(TABLE_USERS, null, values);
            if (result == -1) {
                Log.e("DatabaseHelper", "Error inserting user: " + username);
            } else {
                Log.d("DatabaseHelper", "User created with ID: " + result);
            }
            return result;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error adding user", e);
            return -1;
        } finally {
            db.close();
        }
    }

    // Check user credentials
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            String query;
            String[] args;
            if (password == null || password.isEmpty()) {
                // Check for username only
                query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?";
                args = new String[]{username.trim()};
            } else {
                // Check for username and password
                String hashedPassword = hashPassword(password);
                if (hashedPassword == null) {
                    Log.e("DatabaseHelper", "Hashing failed, cannot verify user");
                    return false;
                }
                query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
                args = new String[]{username.trim(), hashedPassword};
            }
            cursor = db.rawQuery(query, args);
            return cursor.getCount() > 0;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error checking user", e);
            return false;
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // Add a new event
    public void addEvent(String eventName, String eventDate, String eventTime, String eventDescription) {
        if (eventName == null || eventDate == null || eventTime == null || eventDescription == null) {
            throw new IllegalArgumentException("Event details cannot be null");
        }

        try (SQLiteDatabase db = this.getWritableDatabase()) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_EVENT_NAME, eventName);
            values.put(COLUMN_EVENT_DATE, eventDate);
            values.put(COLUMN_EVENT_TIME, eventTime);
            values.put(COLUMN_EVENT_DESCRIPTION, eventDescription);

            long result = db.insert(TABLE_EVENTS, null, values);
            Log.d("DatabaseHelper", "Add event result: " + result);
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error adding event", e);
        }
    }

    // Fetch events by date range
    public Cursor getEventsByDateRange(String startDate, String endDate) {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            return db.rawQuery(
                    "SELECT * FROM " + TABLE_EVENTS + " WHERE " + COLUMN_EVENT_DATE + " BETWEEN ? AND ?",
                    new String[]{startDate, endDate}
            );
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error fetching events by date range", e);
            return null;
        }
    }

    // Fetch event by ID
    public Cursor getEventById(int eventId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM " + TABLE_EVENTS + " WHERE " + COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(eventId)}
        );
    }


    // Update user password
    public int updateUserPassword(String username, String newPassword) {
        try (SQLiteDatabase db = this.getWritableDatabase()) {
            String hashedPassword = hashPassword(newPassword);
            if (hashedPassword == null) return -1;

            ContentValues values = new ContentValues();
            values.put(COLUMN_PASSWORD, hashedPassword);

            int rowsUpdated = db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", new String[]{username.trim()});
            Log.d("DatabaseHelper", "Update password result: " + rowsUpdated);
            return rowsUpdated;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error updating password", e);
            return -1;
        }
    }

    // Delete an event
    public boolean deleteEvent(int eventId) {
        try (SQLiteDatabase db = this.getWritableDatabase()) {
            int result = db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + " = ?", new String[]{String.valueOf(eventId)});
            Log.d("DatabaseHelper", "Delete event result: " + result);
            return result > 0;
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error deleting event", e);
            return false;
        }
    }

    // Update an event
    public int updateEvent(int eventId, String eventName, String eventDate, String eventTime, String eventDescription) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_EVENT_DATE, eventDate);
        values.put(COLUMN_EVENT_TIME, eventTime);
        values.put(COLUMN_EVENT_DESCRIPTION, eventDescription);

        return db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + " = ?", new String[]{String.valueOf(eventId)});
    }

    // Retrieve all events
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            return db.rawQuery("SELECT * FROM " + TABLE_EVENTS, null);
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error retrieving all events", e);
            return null;
        }
    }
}

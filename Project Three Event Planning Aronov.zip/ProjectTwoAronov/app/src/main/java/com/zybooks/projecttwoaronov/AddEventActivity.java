package com.zybooks.projecttwoaronov;

import androidx.appcompat.app.AlertDialog;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        db = new DatabaseHelper(this);

        // Initialize views
        EditText eventNameInput = findViewById(R.id.eventNameInput);
        EditText eventDateInput = findViewById(R.id.eventDateInput);
        EditText eventTimeInput = findViewById(R.id.eventTimeInput);
        EditText eventDescriptionInput = findViewById(R.id.eventDescriptionInput);
        Button saveButton = findViewById(R.id.saveButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        // Save button click handler
        saveButton.setOnClickListener(v -> {
            String eventName = eventNameInput.getText().toString().trim();
            String eventDate = eventDateInput.getText().toString().trim();
            String eventTime = eventTimeInput.getText().toString().trim();
            String eventDescription = eventDescriptionInput.getText().toString().trim();

            if (eventName.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty()) {
                Toast.makeText(this, "Please fill in all required fields.", Toast.LENGTH_SHORT).show();
            } else {
                db.addEvent(eventName, eventDate, eventTime, eventDescription); // Save event to the database
                Toast.makeText(this, "Event added successfully!", Toast.LENGTH_SHORT).show();
                finish(); // Close the activity
            }
        });

        // Cancel button click handler
        cancelButton.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Cancel")
                .setMessage("Are you sure you want to cancel adding the event?")
                .setPositiveButton("Yes", (dialog, which) -> finish())
                .setNegativeButton("No", null)
                .show());
    }
}

package com.zybooks.projecttwoaronov;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SettingsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize UI components
        TextView usernameText = findViewById(R.id.usernameText);
        Switch smsToggle = findViewById(R.id.smsToggle);
        Button changePasswordButton = findViewById(R.id.changePasswordButton);
        Button logoutButton = findViewById(R.id.logoutButton);
        ImageButton homeButton = findViewById(R.id.imageButton4); // Home button
        ImageButton addButton = findViewById(R.id.imageButton5);  // Add button

        // Load saved username
        SharedPreferences prefs = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String username = prefs.getString("username", "Unknown User");
        usernameText.setText("Username: " + username);

        // Load saved SMS toggle state
        SharedPreferences sharedPreferences = getSharedPreferences("SettingsPreferences", MODE_PRIVATE);
        boolean isSmsEnabled = sharedPreferences.getBoolean("smsEnabled", false);
        smsToggle.setChecked(isSmsEnabled);

        // Set SMS Toggle functionality
        smsToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Save the state to SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("smsEnabled", isChecked);
            editor.apply();

            if (isChecked) {
                requestSmsPermission();
            } else {
                Toast.makeText(this, "SMS Notifications Disabled", Toast.LENGTH_SHORT).show();
            }
        });

        // Set Change Password button functionality
        changePasswordButton.setOnClickListener(v -> {
            // Redirect to Change Password Activity
            Intent intent = new Intent(SettingsActivity.this, ChangePasswordActivity.class);
            startActivity(intent);
        });

        // Set Log Out button functionality
        logoutButton.setOnClickListener(v -> {
            // Clear login state and username from SharedPreferences
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear(); // Remove all saved preferences
            editor.apply();

            // Redirect to Login Activity
            Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear activity stack
            startActivity(intent);

            // Show a logout success message
            Toast.makeText(this, "Logged out successfully.", Toast.LENGTH_SHORT).show();
        });

        // Home Button Click Listener
        homeButton.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, DataDisplayActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });

        // Add Button Click Listener
        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, AddEventActivity.class);
            startActivity(intent);
        });
    }

    // Request SMS permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            sendSmsNotification("SMS notifications enabled!");
        }
    }

    // Send SMS Notification
    private void sendSmsNotification(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "+1234567890"; // Replace with a valid number or user input
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Notification sent via SMS!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS notification.", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                sendSmsNotification("SMS notifications enabled!");
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

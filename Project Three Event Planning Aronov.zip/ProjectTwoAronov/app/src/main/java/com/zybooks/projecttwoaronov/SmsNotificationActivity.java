package com.zybooks.projecttwoaronov;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Bundle;

public class SmsNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private TextView permissionMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        permissionMessage = findViewById(R.id.permissionMessage);
        Button grantPermissionButton = findViewById(R.id.grantPermissionButton);
        Button skipPermissionButton = findViewById(R.id.skipPermissionButton);

        grantPermissionButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                // Permission already granted
                permissionMessage.setText(getString(R.string.permission_already_granted));
                Toast.makeText(this, getString(R.string.permission_already_granted), Toast.LENGTH_SHORT).show();
                sendSmsNotification(); // Trigger SMS sending
            } else {
                // Request permission
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE
                );
            }
        });

        // Skip permission and continue using the app
        skipPermissionButton.setOnClickListener(v -> {
            Toast.makeText(this, "SMS permissions skipped. App will function without notifications.", Toast.LENGTH_LONG).show();
            goToMainApp();
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                permissionMessage.setText(getString(R.string.permission_granted));
                Toast.makeText(this, "Permission granted. SMS notifications are now enabled.", Toast.LENGTH_SHORT).show();
                sendSmsNotification(); // Trigger SMS sending
            } else {
                // Permission denied
                permissionMessage.setText(getString(R.string.permission_denied));
                Toast.makeText(this, "Permission denied. The app will function without SMS notifications.", Toast.LENGTH_LONG).show();
                goToMainApp();
            }
        }
    }

    private void sendSmsNotification() {
        try {
            SmsManager smsManager = getSystemService(SmsManager.class);

            // Replace with the user's phone number
            String phoneNumber = "+1234567890";

            // Example static message
            String message = "Permission Granted. Your event notifications are active.";

            // Send SMS
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // Use Log.e for robust logging
            Log.e("SmsNotificationActivity", "Failed to send SMS notification", e);

            // Notify the user about the failure
            Toast.makeText(this, "Failed to send SMS notification.", Toast.LENGTH_SHORT).show();
        }
    }

    private void goToMainApp() {
        Intent intent = new Intent(SmsNotificationActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}

package com.zybooks.projecttwoaronov;

public class Event {
    private int id;
    private final String title;
    private final String date;
    private final String time;
    private final String description;

    // Constructor accepting all fields
    public Event(int id, String title, String date, String time, String description) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
        this.description = description;
    }

    // Getters

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getDescription() {
        return description;
    }

    // Setter for ID

    public void setId(int id) {
        this.id = id;
    }
}


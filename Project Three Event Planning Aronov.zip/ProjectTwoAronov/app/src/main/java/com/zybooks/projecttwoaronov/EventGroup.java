package com.zybooks.projecttwoaronov;

import java.util.List;

public class EventGroup {
    private final String date;
    private final List<Event> events;

    public EventGroup(String date, List<Event> events) {
        this.date = date;
        this.events = events;
    }

    public String getDate() {
        return date;
    }

    public List<Event> getEvents() {
        return events;
    }
}

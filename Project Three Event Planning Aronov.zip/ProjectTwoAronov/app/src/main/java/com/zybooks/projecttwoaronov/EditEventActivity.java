package com.zybooks.projecttwoaronov;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditEventActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private int eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        // Retrieve eventId from Intent
        eventId = getIntent().getIntExtra("eventId", -1);
        if (eventId == -1) {
            Toast.makeText(this, "Error: Invalid event ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        db = new DatabaseHelper(this);

        // Retrieve UI components
        EditText eventNameInput = findViewById(R.id.eventNameInput);
        EditText eventDateInput = findViewById(R.id.eventDateInput);
        EditText eventTimeInput = findViewById(R.id.eventTimeInput);
        EditText eventDescriptionInput = findViewById(R.id.eventDescriptionInput);
        Button saveButton = findViewById(R.id.saveButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        // Fetch and populate event details
        Cursor cursor = db.getEventById(eventId);
        if (cursor != null && cursor.moveToFirst()) {
            eventNameInput.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME)));
            eventDateInput.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE)));
            eventTimeInput.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME)));
            eventDescriptionInput.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESCRIPTION)));
            cursor.close();
        }

        // Handle Save button click
        saveButton.setOnClickListener(v -> {
            String updatedName = eventNameInput.getText().toString().trim();
            String updatedDate = eventDateInput.getText().toString().trim();
            String updatedTime = eventTimeInput.getText().toString().trim();
            String updatedDescription = eventDescriptionInput.getText().toString().trim();

            if (updatedName.isEmpty() || updatedDate.isEmpty() || updatedTime.isEmpty()) {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
                return;
            }

            int rowsUpdated = db.updateEvent(eventId, updatedName, updatedDate, updatedTime, updatedDescription);

            if (rowsUpdated > 0) {
                Toast.makeText(this, "Event updated successfully!", Toast.LENGTH_SHORT).show();
                finish(); // Close activity and return to the previous screen
            } else {
                Toast.makeText(this, "Failed to update event.", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle Cancel button click
        cancelButton.setOnClickListener(v -> finish());
    }
}
